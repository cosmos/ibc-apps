package params

const (
	// Name defines the application name of the app chain.
	Name = "token"

	// BondDenom defines the native staking token denomination.
	BondDenom = "token"

	// DisplayDenom defines the name, symbol, and display value of the token.
	DisplayDenom = "TOKEN"
)
